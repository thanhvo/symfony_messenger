php bin/console debug:container --env-vars
