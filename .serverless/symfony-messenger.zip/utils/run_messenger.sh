php bin/console debug:messenger
php bin/console app:message:dispatcher
