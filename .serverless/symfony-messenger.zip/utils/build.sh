composer dump-autoload --optimize --no-dev --classmap-authoritative
